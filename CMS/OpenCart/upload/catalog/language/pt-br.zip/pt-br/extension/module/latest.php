<?php
// Heading
$_['heading_title'] = 'Novidades';

// Text
$_['text_tax']      = 'Sem impostos:';