<?php
// Text
$_['text_title'] = 'Alipay';