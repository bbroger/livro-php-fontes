<?php
$_['text_klarna_fee'] = 'Klarna Fee';