<?php
// Heading
$_['heading_title'] = 'Destaques';

// Text
$_['text_tax']      = 'Sem impostos:';