<?php
// Text
$_['text_title']       = 'Depósito bancário';
$_['text_instruction'] = 'Instruções';
$_['text_description'] = 'Deposite o valor total do pedido na conta:';
$_['text_payment']     = 'Seu pedido será liberado após identificarmos o pagamento.';