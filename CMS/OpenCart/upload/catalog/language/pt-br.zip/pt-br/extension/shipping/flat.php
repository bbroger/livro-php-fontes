<?php
// Text
$_['text_title']       = 'Frete fixo';
$_['text_description'] = 'Frete fixo';