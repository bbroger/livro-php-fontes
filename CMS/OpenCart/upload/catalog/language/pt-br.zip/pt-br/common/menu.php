<?php
// Text
$_['text_all'] = 'Todos em';