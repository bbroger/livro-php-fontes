<?php
// Text
$_['text_subject']  = '%s - Nova transação em sua conta';
$_['text_received'] = 'Sua conta na loja %s, teve um registro de transação.';
$_['text_amount']   = 'Valor da transação:';
$_['text_total']    = 'Saldo atual:';