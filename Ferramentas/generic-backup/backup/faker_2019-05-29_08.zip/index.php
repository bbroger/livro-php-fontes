<?php
ini_set('max_execution_time', '-1');// Ilimitados
ini_set('max_input_time', 120);// s
ini_set('max_input_nesting_level', 64);//s
ini_set('memory_limit', '-1');//Ilimitada

// require the Faker autoloader
require_once 'vendor/autoload.php';
// alternatively, use another PSR-0 compliant autoloader (like the Symfony2 ClassLoader for instance)

// use the factory to create a Faker\Generator instance
//$faker = Faker\Factory::create();
$faker = Faker\Factory::create('pt_BR');
/*
$cliente = "CREATE TABLE clientes (
    id int primary key auto_increment,
    nome varchar(50),
    email varchar(50),
    cpf varchar(15),
    credito_liberado char(1),
    nascimento date,
    categoria_id int not null
);\n\n";
*/
$cliente .= "INSERT INTO `clientes` (`cpf`, `nome`, `credito_liberado`, `data_nasc`, `email`, `user_id`) VALUES \n";

function stringGen($length = 4) {
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

$produtos = array("Banana", "Laranja", "Manga", "Mamão", "Goiaba");

for ($i=0; $i < 100; $i++) {   
    $cpf = $faker->numberBetween($min = 10000000000, $max = 99999999999);
    $nome = addslashes($faker->name);
    $credito_liberado = $faker->regexify('[sn]');
    $data_nasc = $faker->date;
    $email = $faker->email;
    $user_id = $faker->numberBetween($min = 1, $max = 4);

    if($i<99){
        $cliente .= "('$cpf', '$nome','$credito_liberado','$data_nasc','$email','$user_id'),\n";
    }else{
        $cliente .= "('$cpf', '$nome','$credito_liberado','$data_nasc','$email','$user_id');\n";
    }
}

$fp = fopen("clientes.sql", "w");
$escreve = fwrite($fp, $cliente);
fclose($fp);

print 'Arquivo criado';

